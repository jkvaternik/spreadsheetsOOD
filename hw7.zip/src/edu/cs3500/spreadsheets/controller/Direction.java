package edu.cs3500.spreadsheets.controller;

/**
 * Represents one of the four main directions, one for each arrow key.
 */
public enum Direction {
  LEFT, RIGHT, DOWN, UP
}
