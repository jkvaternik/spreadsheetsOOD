package edu.cs3500.spreadsheets.model.cell.formula.function;

/**
 * Enum class representing the available functions.
 */
public enum EFunctions {
  SUM, PRODUCT, LESSTHAN, CAPITALIZE

}
